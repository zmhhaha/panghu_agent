"""Signed JWT, proxy-peer, issuer/sub and Origin/CSRF boundary checks."""
from types import SimpleNamespace
from datetime import datetime,timedelta,timezone
import jwt,pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient
from ppt_service.server.app import create_app
from ppt_service.server.auth import Settings
from ppt_service.server.migrate import migrate

@pytest.fixture
def auth_client(tmp_path):
    engine=create_engine('sqlite://',connect_args={'check_same_thread':False},poolclass=StaticPool);migrate(engine)
    config=Settings('sqlite://',str(tmp_path),oidc_issuer='https://casdoor.test',oidc_audience='ppt',trusted_proxy_cidrs=('127.0.0.1/32',),allowed_origins=('https://ppt.test',),invitation_subjects=('stable-alice',))
    app=create_app(config,engine)
    key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
    app.state.jwks=SimpleNamespace(get_signing_key_from_jwt=lambda token:SimpleNamespace(key=key.public_key()))
    def token(**overrides):
        claims={'iss':'https://casdoor.test','sub':'stable-alice','aud':'ppt','iat':datetime.now(timezone.utc),'exp':datetime.now(timezone.utc)+timedelta(minutes=5)}|overrides
        return jwt.encode(claims,key,algorithm='RS256')
    c=TestClient(app,base_url='https://ppt.test',client=('127.0.0.1',12345))
    return app,c,token

def test_signed_identity_and_csrf(auth_client):
    app,c,token=auth_client;headers={'Authorization':'Bearer '+token(),'X-Auth-Request-User':'mallory'}
    me=c.get('/api/v1/me',headers=headers);assert me.status_code==200;assert me.json()['sub']=='stable-alice'
    assert c.post('/api/v1/projects',json={'title':'ok'},headers=headers).status_code==403
    mutation=headers|{'Origin':'https://ppt.test','X-CSRF-Token':me.json()['csrf_token']}
    assert c.post('/api/v1/projects',json={'title':'ok'},headers=mutation).status_code==201
    assert c.post('/api/v1/projects',json={'title':'bad'},headers=mutation|{'Origin':'https://evil.test'}).status_code==403
    assert c.post('/api/v1/projects',json={'title':'bad'},headers=mutation|{'X-CSRF-Token':'wrong'}).status_code==403

@pytest.mark.parametrize('claims',[{'iss':'https://other.test'},{'sub':'uninvited'},{'aud':'other'},{'exp':datetime.now(timezone.utc)-timedelta(seconds=60)}])
def test_invalid_claims_reject(auth_client,claims):
    app,c,token=auth_client
    assert c.get('/api/v1/me',headers={'Authorization':'Bearer '+token(**claims)}).status_code==401

def test_untrusted_peer_rejects_even_valid_jwt(auth_client):
    app,c,token=auth_client
    other=TestClient(app,base_url='https://ppt.test',client=('192.0.2.3',12345))
    assert other.get('/api/v1/me',headers={'Authorization':'Bearer '+token(),'X-Forwarded-For':'127.0.0.1'}).status_code==401
